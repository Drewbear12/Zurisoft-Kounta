using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KountaApp.Pages
{
    public class ConsolidatedReportModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
