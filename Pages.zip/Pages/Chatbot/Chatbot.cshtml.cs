using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KountaApp.Pages.Chatbot
{
    public class ChatbotModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
