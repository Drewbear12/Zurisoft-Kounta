using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KountaApp.Pages.Transaction
{
    public class TransactionModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
