using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KountaApp.Pages
{
    public class salesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
