﻿namespace KountaApp.Sender_Settings
{
    public class SendGridSettings
    {
        public string FromEmail { get; set; }
        public string EmailName { get; set; }
        public string ApiKey { get; set; }
    }
}
